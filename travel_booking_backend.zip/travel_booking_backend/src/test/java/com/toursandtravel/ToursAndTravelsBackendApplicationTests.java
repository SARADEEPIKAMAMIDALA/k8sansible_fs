package com.toursandtravel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToursAndTravelsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
